package modele;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Algorithmes {

    /**
     * Algorithme simple :
     * Respecte les contraintes vendeur → acheteur
     * Parcourt les villes dans l’ordre des ventes
     */
    public static List<String> algoSimple(Scenario scenario) {
        List<String> parcours = new ArrayList<>();
        Set<String> dejaPasse = new HashSet<>();

        // Commence à Vélizy
        parcours.add("Vélizy");

        for (Vente vente : scenario.getVentes()) {
            String villeVendeur = vente.getVendeur().getVille();
            String villeAcheteur = vente.getAcheteur().getVille();

            if (!dejaPasse.contains(villeVendeur)) {
                parcours.add(villeVendeur);
                dejaPasse.add(villeVendeur);
            }
            if (!dejaPasse.contains(villeAcheteur)) {
                parcours.add(villeAcheteur);
                dejaPasse.add(villeAcheteur);
            }
        }

        // Retour à Vélizy
        parcours.add("Vélizy");
        return parcours;
    }

    /**
     * Calcule la distance totale d’un parcours
     */
    public static int calculDistance(List<String> parcours, CarteFrance carte) {
        int distanceTotale = 0;
        for (int i = 0; i < parcours.size() - 1; i++) {
            String ville1 = parcours.get(i);
            String ville2 = parcours.get(i + 1);
            distanceTotale += carte.getDistance(ville1, ville2);
        }
        return distanceTotale;
    }
}
