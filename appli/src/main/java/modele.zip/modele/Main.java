package modele;
//package controleur;
import modele.*;
import java.util.List;

public class Main {
        public static void main(String[] args) {
            // Chargement des données
            List<Membre> membres = Donnees.lireMembres("data/membres_APPLI.txt");
            CarteFrance carte = Donnees.lireCarte("data/distances.txt");
            Scenario scenario0 = Donnees.lireScenario("data/scenario_0.txt", membres);

            // Affichage simple pour vérifier que tout est bien lu
            System.out.println("Membres :");
            for (Membre m : membres) {
                System.out.println(m.getPseudo() + " - " + m.getVille());
            }

            System.out.println("\nVentes du scénario :");
            for (Vente v : scenario0.getVentes()) {
                System.out.println(v.getVendeur().getPseudo() + " → " + v.getAcheteur().getPseudo());
            }

            System.out.println("\nCarte chargée.");
            System.out.println(carte.toString());

            System.out.println(Algorithmes.algoSimple(scenario0));
        }


}


